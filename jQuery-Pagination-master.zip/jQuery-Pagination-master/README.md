## jQuery Pagination

This is a simple demonstration on how to implement pagination using jQuery.

A working example can be found [here](https://codepen.io/gugui3z24/pen/VzZzgr). Additionally, a YouTube tutorial video illustrating how to create this application from scratch can be found [here](https://youtu.be/Xznn-ggD0GU).

## Description

This application was created to demonstrate how to utilize jQuery to implement pagination in order to limit items displayed on each page (without the use of any plugins).

## Installation

- Open the HTML file index.html in your browser.

## Contributors

David Acosta.

## License

No license.
